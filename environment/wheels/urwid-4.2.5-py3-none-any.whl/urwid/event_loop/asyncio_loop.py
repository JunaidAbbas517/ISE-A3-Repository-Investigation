# Urwid main loop code
#    Copyright (C) 2004-2012  Ian Ward
#    Copyright (C) 2008 Walter Mundt
#    Copyright (C) 2009 Andrew Psaltis
#
#    This library is free software; you can redistribute it and/or
#    modify it under the terms of the GNU Lesser General Public
#    License as published by the Free Software Foundation; either
#    version 2.1 of the License, or (at your option) any later version.
#
#    This library is distributed in the hope that it will be useful,
#    but WITHOUT ANY WARRANTY; without even the implied warranty of
#    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the GNU
#    Lesser General Public License for more details.
#
#    You should have received a copy of the GNU Lesser General Public
#    License along with this library; if not, write to the Free Software
#    Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA  02111-1307  USA
#
# Urwid web site: https://urwid.org/

"""Asyncio based urwid EventLoop implementation."""

from __future__ import annotations

import asyncio
import functools
import inspect
import logging
import sys
import typing

from .abstract_loop import EventLoop, ExitMainLoop

if typing.TYPE_CHECKING:
    from collections.abc import Callable
    from concurrent.futures import Executor

    from typing_extensions import ParamSpec

    _Spec = ParamSpec("_Spec")
    _T = typing.TypeVar("_T")

__all__ = ("AsyncioEventLoop",)


class AsyncioEventLoop(EventLoop):
    """
    Event loop based on the standard library ``asyncio`` module.

    .. warning::
        Under Windows, AsyncioEventLoop globally enforces WindowsSelectorEventLoopPolicy
        as a side-effect of creating a class instance.
        Original event loop policy is restored in destructor method.

    .. note::
        If you make any changes to the urwid state outside of it
        handling input or responding to alarms (for example, from asyncio.Task
        running in background), and wish the screen to be
        redrawn, you must call :meth:`MainLoop.draw_screen` method of the
        main loop manually.

        A good way to do this:
            asyncio.get_event_loop().call_soon(main_loop.draw_screen)

    .. note::
        :meth:`alarm`, :meth:`watch_file` and :meth:`enter_idle` accept an ``async def``
        callback in addition to a plain callable. A coroutine function is scheduled as
        an ``asyncio.Task`` instead of being called directly.
    """

    def __init__(self, *, loop: asyncio.AbstractEventLoop | None = None, **kwargs: typing.Any) -> None:
        """Wrap `loop`, or the current asyncio event loop when none is given."""
        super().__init__()
        self.logger = logging.getLogger(__name__).getChild(self.__class__.__name__)

        if sys.version_info[:2] < (3, 11):
            self._event_loop_policy_altered: bool = False
            self._original_event_loop_policy: asyncio.AbstractEventLoopPolicy | None = None

            if loop:
                self._loop: asyncio.AbstractEventLoop = loop
            else:
                self._original_event_loop_policy = asyncio.get_event_loop_policy()
                if sys.platform == "win32" and not isinstance(
                    self._original_event_loop_policy, asyncio.WindowsSelectorEventLoopPolicy
                ):
                    self.logger.debug("Set WindowsSelectorEventLoopPolicy as asyncio event loop policy")
                    asyncio.set_event_loop_policy(
                        asyncio.WindowsSelectorEventLoopPolicy()  # pylint: disable=deprecated-class
                    )
                    self._event_loop_policy_altered = True
                else:
                    self._event_loop_policy_altered = False

                try:
                    self._loop = asyncio.get_event_loop()
                except RuntimeError:
                    # get_event_loop() only auto-creates a loop the first time it is ever called in
                    # this thread (CPython's BaseDefaultEventLoopPolicy._set_called guard): once
                    # something else has called set_event_loop() - e.g. a test fixture resetting it
                    # to None during teardown - a later get_event_loop() call raises instead of
                    # creating a replacement, even though nothing is currently running one.
                    self._loop = asyncio.new_event_loop()
                    asyncio.set_event_loop(self._loop)

        else:
            self._runner: asyncio.Runner | None = None

            if loop:
                self._loop: asyncio.AbstractEventLoop = loop
            else:
                try:
                    self._loop = asyncio.get_running_loop()
                except RuntimeError:
                    self._runner = asyncio.Runner(loop_factory=asyncio.SelectorEventLoop)
                    self._loop = self._runner.get_loop()

        self._exc: BaseException | None = None

        self._idle_asyncio_handle: asyncio.TimerHandle | None = None
        self._idle_handle: int = 0
        self._idle_callbacks: dict[int, Callable[[], typing.Any]] = {}
        self._background_tasks: set[asyncio.Task[typing.Any]] = set()

    def __del__(self) -> None:
        """Restore the original event loop policy or close the runner, as appropriate for this Python version."""
        if sys.version_info[:2] < (3, 11):
            if self._event_loop_policy_altered:
                asyncio.set_event_loop_policy(self._original_event_loop_policy)  # Restore default event loop policy
        elif self._runner is not None:
            self._runner.close()

    def _also_call_idle(self, callback: Callable[_Spec, _T]) -> Callable[_Spec, _T | None]:
        """Wrap the callback to also call _entering_idle."""

        @functools.wraps(callback)
        def wrapper(*args: _Spec.args, **kwargs: _Spec.kwargs) -> _T | None:
            if not self._idle_asyncio_handle:
                self._idle_asyncio_handle = self._loop.call_later(0, self._entering_idle)
            return self._run_callback(callback, *args, **kwargs)

        return wrapper

    def _run_callback(self, callback: Callable[_Spec, _T], *args: _Spec.args, **kwargs: _Spec.kwargs) -> _T | None:
        """Call callback, scheduling it as a task instead if it is a coroutine function.

        :param callback: function or coroutine function to call
        :param args: positional arguments to pass to callback
        :param kwargs: keyword arguments to pass to callback
        :return: callback return value, or None if it was scheduled as a background task
        """
        if inspect.iscoroutinefunction(callback):
            task = self._loop.create_task(callback(*args, **kwargs))
            self._background_tasks.add(task)
            task.add_done_callback(self._background_tasks.discard)
            task.add_done_callback(self._background_task_done)
            return None
        return callback(*args, **kwargs)

    def _background_task_done(self, task: asyncio.Task[typing.Any]) -> None:
        """Report a background task's exception directly rather than relying on GC.

        A background task's exception would otherwise only surface through asyncio's
        "Task exception was never retrieved" mechanism, which CPython triggers from
        ``Task.__del__`` as soon as the task is refcounted to zero. PyPy and GraalPy use
        tracing garbage collectors instead, so that finalizer runs at an unpredictable
        time (if at all before the process exits), leaving :meth:`run` blocked forever
        on an exception - including a plain :exc:`ExitMainLoop` - that already happened.
        """
        if task.cancelled():
            return
        if exc := task.exception():
            self._exception_handler(self._loop, {"exception": exc})

    def _entering_idle(self) -> None:
        """Call all the registered idle callbacks."""
        try:
            for callback in self._idle_callbacks.values():
                self._run_callback(callback)
        finally:
            self._idle_asyncio_handle = None

    def run_in_executor(
        self,
        executor: Executor | None,
        func: Callable[_Spec, _T],
        *args: _Spec.args,
        **kwargs: _Spec.kwargs,
    ) -> asyncio.Future[_T]:
        """Run callable in executor.

        :param executor: Executor to use for running the function. Default asyncio executor is used if None.
        :param func: function to call
        :param args: arguments to function (positional only)
        :param kwargs: keyword arguments to function (keyword only)
        :return: future object for the function call outcome.
        """
        return self._loop.run_in_executor(executor, functools.partial(func, *args, **kwargs))

    def alarm(self, seconds: float, callback: Callable[[], typing.Any]) -> asyncio.TimerHandle:
        """Call callback() a given time from now.

        No parameters are passed to callback. Returns a handle that may be passed to remove_alarm().

        :param seconds: time in seconds to wait before calling callback
        :param callback: function to call from event loop
        """
        return self._loop.call_later(seconds, self._also_call_idle(callback))

    def remove_alarm(self, handle: asyncio.TimerHandle) -> bool:
        """
        Remove an alarm.

        Returns True if the alarm exists, False otherwise
        """
        existed = not handle.cancelled()
        handle.cancel()
        return existed

    def watch_file(self, fd: int, callback: Callable[[], typing.Any]) -> int:
        """Call callback() when fd has some data to read.

        No parameters are passed to callback. Returns a handle that may be passed to remove_watch_file().

        :param fd: file descriptor to watch for input
        :param callback: function to call when input is available
        """
        self._loop.add_reader(fd, self._also_call_idle(callback))
        return fd

    def remove_watch_file(self, handle: int) -> bool:
        """
        Remove an input file.

        Returns True if the input file exists, False otherwise
        """
        return self._loop.remove_reader(handle)

    def enter_idle(self, callback: Callable[[], typing.Any]) -> int:
        """
        Add a callback for entering idle.

        Returns a handle that may be passed to remove_enter_idle()
        """
        # XXX there's no such thing as "idle" in most event loops; this fakes
        # it by adding extra callback to the timer and file watch callbacks.
        self._idle_handle += 1
        self._idle_callbacks[self._idle_handle] = callback
        return self._idle_handle

    def remove_enter_idle(self, handle: int) -> bool:
        """
        Remove an idle callback.

        Returns True if the handle was removed.
        """
        try:
            del self._idle_callbacks[handle]
        except KeyError:
            return False
        return True

    def _exception_handler(self, loop: asyncio.AbstractEventLoop, context: dict[str, typing.Any]) -> None:
        if exc := context.get("exception"):
            loop.stop()

            if self._idle_asyncio_handle:
                # clean it up to prevent old callbacks
                # from messing things up if loop is restarted
                self._idle_asyncio_handle.cancel()
                self._idle_asyncio_handle = None

            if not isinstance(exc, ExitMainLoop):
                # Store the exc_info so we can re-raise after the loop stops
                self._exc = exc
        else:
            loop.default_exception_handler(context)

    def run(self) -> None:
        """Start the event loop.

        Exit the loop when any callback raises an exception.
        If ExitMainLoop is raised, exit cleanly.

        :raises BaseException: the exception that stopped the loop, once the loop has been left.
        """
        # The handler stops the loop on any exception, so it must not stay on a loop shared with other code.
        previous_handler = self._loop.get_exception_handler()
        self._loop.set_exception_handler(self._exception_handler)
        try:
            self._loop.run_forever()
        finally:
            self._loop.set_exception_handler(previous_handler)
        if self._exc:
            exc = self._exc
            self._exc = None
            raise exc.with_traceback(exc.__traceback__)
