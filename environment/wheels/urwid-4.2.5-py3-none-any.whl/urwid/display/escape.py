# Urwid escape sequences common to curses_display and raw_display
#    Copyright (C) 2004-2011  Ian Ward
#
#    This library is free software; you can redistribute it and/or
#    modify it under the terms of the GNU Lesser General Public
#    License as published by the Free Software Foundation; either
#    version 2.1 of the License, or (at your option) any later version.
#
#    This library is distributed in the hope that it will be useful,
#    but WITHOUT ANY WARRANTY; without even the implied warranty of
#    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the GNU
#    Lesser General Public License for more details.
#
#    You should have received a copy of the GNU Lesser General Public
#    License along with this library; if not, write to the Free Software
#    Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA  02111-1307  USA
#
# Urwid web site: https://urwid.org/


"""Terminal Escape Sequences for input and display."""

from __future__ import annotations

import enum
import functools
import re
import sys
import typing
from collections.abc import MutableMapping

from urwid import str_util

if typing.TYPE_CHECKING:
    from collections.abc import Iterable

    _KeyQueueData = dict[int, typing.Union[str, "_KeyQueueData"]]
    _MouseInput = tuple[str, int, int, int]
    _CursorPosition = tuple[typing.Literal["cursor position"], int, int]
    _PrivateModeReport = tuple[typing.Literal["private mode report"], str, int]

IS_WINDOWS = sys.platform == "win32"

within_double_byte = str_util.within_double_byte

SO = "\x0e"
SI = "\x0f"
# Encoded once here, because `urwid.util.apply_target_encoding` splits on them for every rendered text segment.
_SO_BYTES = SO.encode("ascii")
_SI_BYTES = SI.encode("ascii")
_SI_SO = SI + SO
IBMPC_ON = "\x1b[11m"
IBMPC_OFF = "\x1b[10m"

DEC_TAG = "0"
DEC_SPECIAL_CHARS = "▮◆▒␉␌␍␊°±␤␋┘┐┌└┼⎺⎻─⎼⎽├┤┴┬│≤≥π≠£·"
ALT_DEC_SPECIAL_CHARS = "_`abcdefghijklmnopqrstuvwxyz{|}~"

DEC_SPECIAL_CHARMAP = {}
if len(DEC_SPECIAL_CHARS) != len(ALT_DEC_SPECIAL_CHARS):
    raise RuntimeError(repr((DEC_SPECIAL_CHARS, ALT_DEC_SPECIAL_CHARS)))

for c, alt in zip(DEC_SPECIAL_CHARS, ALT_DEC_SPECIAL_CHARS):
    DEC_SPECIAL_CHARMAP[ord(c)] = SO + alt + SI

SAFE_ASCII_DEC_SPECIAL_RE = re.compile(f"^[ -~{DEC_SPECIAL_CHARS}]*$")
DEC_SPECIAL_RE = re.compile(f"[{DEC_SPECIAL_CHARS}]")

# the most common ord() calls used for numeric decode, pre-calculate once
_ORD_0 = ord("0")
_ORD_9 = ord("9")
# longest "Pb;Px;Py" body of an SGR mouse report accepted before its "M"/"m" terminator
_SGR_MOUSE_MAX_LEN = 32

###################
# Input sequences
###################


class MoreInputRequired(Exception):
    """Raised when the input decoded so far is a prefix of a longer escape sequence."""


def escape_modifier(digit: str) -> str:
    """Translate a CSI modifier digit into the "shift "/"meta "/"ctrl " prefix combination it encodes."""
    mode = ord(digit) - ord("1")
    return "shift " * (mode & 1) + "meta " * ((mode & 2) // 2) + "ctrl " * ((mode & 4) // 4)


input_sequences: list[tuple[str, str]] = [
    ("[A", "up"),
    ("[B", "down"),
    ("[C", "right"),
    ("[D", "left"),
    ("[E", "5"),
    ("[F", "end"),
    ("[G", "5"),
    ("[H", "home"),
    ("[I", "focus in"),
    ("[O", "focus out"),
    ("[1~", "home"),
    ("[2~", "insert"),
    ("[3~", "delete"),
    ("[4~", "end"),
    ("[5~", "page up"),
    ("[6~", "page down"),
    ("[7~", "home"),
    ("[8~", "end"),
    ("[[A", "f1"),
    ("[[B", "f2"),
    ("[[C", "f3"),
    ("[[D", "f4"),
    ("[[E", "f5"),
    ("[11~", "f1"),
    ("[12~", "f2"),
    ("[13~", "f3"),
    ("[14~", "f4"),
    ("[15~", "f5"),
    ("[17~", "f6"),
    ("[18~", "f7"),
    ("[19~", "f8"),
    ("[20~", "f9"),
    ("[21~", "f10"),
    ("[23~", "f11"),
    ("[24~", "f12"),
    ("[25~", "f13"),
    ("[26~", "f14"),
    ("[28~", "f15"),
    ("[29~", "f16"),
    ("[31~", "f17"),
    ("[32~", "f18"),
    ("[33~", "f19"),
    ("[34~", "f20"),
    ("OA", "up"),
    ("OB", "down"),
    ("OC", "right"),
    ("OD", "left"),
    ("OH", "home"),
    ("OF", "end"),
    ("OP", "f1"),
    ("OQ", "f2"),
    ("OR", "f3"),
    ("OS", "f4"),
    ("Oo", "/"),
    ("Oj", "*"),
    ("Om", "-"),
    ("Ok", "+"),
    ("[Z", "shift tab"),
    ("On", "."),
    ("[200~", "begin paste"),
    ("[201~", "end paste"),
    *(
        (prefix + letter, modifier + key)
        for prefix, modifier in zip("O[", ("meta ", "shift "))
        for letter, key in zip("abcd", ("up", "down", "right", "left"))
    ),
    *(
        (f"[{digit}{symbol}", modifier + key)
        for modifier, symbol in zip(("shift ", "meta "), "$^")
        for digit, key in zip("235678", ("insert", "delete", "page up", "page down", "home", "end"))
    ),
    *((f"O{ord('p') + n:c}", str(n)) for n in range(10)),
    *(
        # modified cursor keys + home, end, 5 -- [#X and [1;#X forms
        (prefix + digit + letter, escape_modifier(digit) + key)
        for prefix in ("[", "[1;")
        for digit in "12345678"
        for letter, key in zip("ABCDEFGH", ("up", "down", "right", "left", "5", "end", "5", "home"))
    ),
    *(
        # modified F1-F4 keys - O#X form and [1;#X form
        (prefix + digit + letter, escape_modifier(digit) + f"f{number}")
        for prefix in ("O", "[1;")
        for digit in "12345678"
        for number, letter in enumerate("PQRS", start=1)
    ),
    *(
        # modified F1-F13 keys -- [XX;#~ form
        (f"[{num!s};{digit}~", escape_modifier(digit) + key)
        for digit in "12345678"
        for num, key in zip(
            (3, 5, 6, 11, 12, 13, 14, 15, 17, 18, 19, 20, 21, 23, 24, 25, 26, 28, 29, 31, 32, 33, 34),
            (
                "delete",
                "page up",
                "page down",
                *(f"f{idx}" for idx in range(1, 21)),
            ),
        )
    ),
    # mouse reporting (special handling done in KeyqueueTrie)
    ("[M", "mouse"),
    # mouse reporting for SGR 1006
    ("[<", "sgrmouse"),
    # report status response
    ("[0n", "status ok"),
]


class KeyqueueTrie:
    """Trie mapping terminal escape sequences to the key names they decode to."""

    __slots__ = ("data",)

    def __init__(self, sequences: Iterable[tuple[str, str]]) -> None:
        """
        Build a trie of the given ``(escape sequence, key name)`` pairs.

        :raises TypeError: two sequences collide in the trie.
        """
        self.data: _KeyQueueData = {}
        for s, result in sequences:
            if isinstance(result, dict):
                raise TypeError(result)
            self.add(self.data, s, result)

    def add(
        self,
        root: _KeyQueueData,
        s: str,
        result: str,
    ) -> None:
        """
        Add one ``(escape sequence, key name)`` pair to the trie.

        :raises RuntimeError: the sequence collides with a shorter one already in the trie.
        :raises ValueError: the sequence collides with a longer one already in the trie.
        """
        if not isinstance(root, MutableMapping) or not s:
            raise RuntimeError("trie conflict detected")

        seq_start = ord(s[0])
        if seq_start in root:
            child = root[seq_start]
            if isinstance(child, str):
                raise ValueError("trie conflict detected")

            self.add(child, s[1:], result)
            return
        if len(s) > 1:
            d: _KeyQueueData = {}
            root[seq_start] = d
            self.add(d, s[1:], result)
            return
        root[seq_start] = result

    def get(
        self,
        keys: list[int],
        more_available: bool,
    ) -> tuple[str | _MouseInput | _CursorPosition | _PrivateModeReport, list[int]] | None:
        """Decode the longest key sequence matching the start of ``keys``, trying the trie then the special reports."""
        result: tuple[str | _MouseInput | _CursorPosition | _PrivateModeReport, list[int]] | None
        if result := self.get_recurse(self.data, keys, more_available):
            return result

        if (result := self.read_private_mode_report(keys, more_available)) is not None:
            return result

        return self.read_cursor_position(keys, more_available)

    def get_recurse(
        self,
        root: (_KeyQueueData | str),
        keys: list[int],
        more_available: bool,
    ) -> tuple[str | _MouseInput, list[int]] | None:
        """
        Walk the trie for the next key, consuming codes as it goes.

        :raises MoreInputRequired: the codes end in the middle of a sequence and *more_available* is set.
        """
        if not isinstance(root, MutableMapping):
            if root == "mouse":
                return self.read_mouse_info(keys, more_available)

            if root == "sgrmouse":
                return self.read_sgrmouse_info(keys, more_available)

            return (root, keys)

        if not keys:
            # get more keys
            if more_available:
                raise MoreInputRequired()
            return None

        if keys[0] not in root:
            return None

        return self.get_recurse(root[keys[0]], keys[1:], more_available)

    def read_mouse_info(
        self,
        keys: list[int],
        more_available: bool,
    ) -> tuple[_MouseInput, list[int]] | None:
        """Read an X10 mouse report from the codes and return the resulting input.

        :raises MoreInputRequired: the codes end in the middle of a sequence and *more_available* is set.
        """
        if len(keys) < 3:
            if more_available:
                raise MoreInputRequired()
            return None

        b = keys[0] - _MOUSE_BYTE_OFFSET
        # supports 0-255
        x, y = (keys[1] - _MOUSE_COORD_OFFSET) % 256, (keys[2] - _MOUSE_COORD_OFFSET) % 256

        prefixes = []
        if b & _MOUSE_SHIFT_FLAG:
            prefixes.append("shift ")
        if b & _MOUSE_META_FLAG:
            prefixes.append("meta ")
        if b & _MOUSE_CTRL_FLAG:
            prefixes.append("ctrl ")
        multi_click = (b & MOUSE_MULTIPLE_CLICK_MASK) >> 9
        if multi_click == 1:
            prefixes.append("double ")
        elif multi_click == 2:
            prefixes.append("triple ")
        prefix = "".join(prefixes)

        button_bits = b & _MOUSE_BUTTON_MASK
        if b & _MOUSE_EXTRA_BUTTON_FLAG:
            button = 8 + button_bits
        elif b & _MOUSE_HIGH_BUTTON_FLAG:
            button = 4 + button_bits
        else:
            button = 1 + button_bits

        if button_bits == _MOUSE_BUTTON_MASK and not b & (_MOUSE_HIGH_BUTTON_FLAG | _MOUSE_EXTRA_BUTTON_FLAG):
            action = "release"
            button = 0
        elif b & MOUSE_RELEASE_FLAG:
            action = "release"
        elif b & MOUSE_DRAG_FLAG:
            action = "drag"
        elif multi_click:
            action = "click"
        else:
            action = "press"

        return ((f"{prefix}mouse {action}", button, x, y), keys[3:])

    def read_sgrmouse_info(
        self,
        keys: list[int],
        more_available: bool,
    ) -> tuple[_MouseInput, list[int]] | None:
        # Helpful links:
        # https://stackoverflow.com/questions/5966903/how-to-get-mousemove-and-mouseclick-in-bash
        # http://invisible-island.net/xterm/ctlseqs/ctlseqs.pdf
        """Read an SGR mouse report from the codes and return the resulting input.

        :returns: the mouse event and the codes left after the report,
            or None when the codes do not start with an SGR mouse report.
        :raises MoreInputRequired: the codes end in the middle of a sequence and *more_available* is set.
        """
        if not keys:
            if more_available:
                raise MoreInputRequired()
            return None

        # Anything other than "Pb;Px;Py" digits before the terminator, or a longer run, is not a report: it is
        # rejected here instead of being buffered while waiting for a terminator that may never come.
        for pos_m in range(min(len(keys), _SGR_MOUSE_MAX_LEN + 1)):
            k = keys[pos_m]
            if k in {ord("M"), ord("m")}:
                break
            if not (_ORD_0 <= k <= _ORD_9 or k == ord(";")):
                return None
        else:
            if more_available and len(keys) <= _SGR_MOUSE_MAX_LEN:
                raise MoreInputRequired()
            return None

        fields = bytes(keys[:pos_m]).split(b";")
        if len(fields) != 3 or not all(fields):
            return None
        b, x, y = (int(field) for field in fields)
        action = chr(keys[pos_m])
        # Double and triple clicks are not supported.
        # They can be implemented by using a timer.
        # This timer can check if the last registered click is below a certain threshold.
        # This threshold is normally set in the operating system itself,
        # so setting one here will cause an inconsistent behaviour.

        prefixes = []
        if b & _MOUSE_SHIFT_FLAG:
            prefixes.append("shift ")
        if b & _MOUSE_META_FLAG:
            prefixes.append("meta ")
        if b & _MOUSE_CTRL_FLAG:
            prefixes.append("ctrl ")
        prefix = "".join(prefixes)

        button_bits = b & _MOUSE_BUTTON_MASK
        if b & _MOUSE_EXTRA_BUTTON_FLAG:
            button = 8 + button_bits
        elif b & _MOUSE_HIGH_BUTTON_FLAG:
            button = 4 + button_bits
        else:
            button = 1 + button_bits
        x -= 1
        y -= 1

        if action == "M":
            if b & MOUSE_DRAG_FLAG:
                action = "drag"
            else:
                action = "press"
        else:
            action = "release"

        return ((f"{prefix}mouse {action}", button, x, y), keys[pos_m + 1 :])

    def read_private_mode_report(
        self,
        keys: list[int],
        more_available: bool,
    ) -> tuple[_PrivateModeReport, list[int]] | None:
        """Interpret a DECRPM reply (CSI ? Pd ; Ps $ y).

        :returns: ``('private mode report', mode, value)``.
        :raises MoreInputRequired: the codes end in the middle of a sequence and *more_available* is set.
        """
        if not keys:
            if more_available:
                raise MoreInputRequired()
            return None
        if keys[0] != ord("["):
            return None
        if len(keys) < 2:
            if more_available:
                raise MoreInputRequired()
            return None
        if keys[1] != ord("?"):
            return None
        # read the mode number
        mode = ""
        i = 2
        for k in keys[i:]:
            i += 1
            if k == ord(";"):
                if not mode:
                    return None
                break
            if k < _ORD_0 or k > _ORD_9:
                return None
            mode += chr(k)
        else:
            if more_available:
                raise MoreInputRequired()
            return None
        if not keys[i:]:
            if more_available:
                raise MoreInputRequired()
            return None
        # Ps: "0" is a valid value here (mode not recognized), unlike the mode number above.
        value = 0
        got_digit = False
        for k in keys[i:]:
            i += 1
            if k == ord("$"):
                break
            if k < _ORD_0 or k > _ORD_9:
                return None
            value = value * 10 + k - _ORD_0
            got_digit = True
        else:
            if more_available:
                raise MoreInputRequired()
            return None
        if not got_digit:
            return None
        if not keys[i:]:
            if more_available:
                raise MoreInputRequired()
            return None
        if keys[i] != ord("y"):
            return None
        return (("private mode report", mode, value), keys[i + 1 :])

    def read_cursor_position(
        self,
        keys: list[int],
        more_available: bool,
    ) -> tuple[_CursorPosition, list[int]] | None:
        """
        Interpret cursor position information being sent by the user's terminal.

        :returns: ('cursor position', x, y) where (x, y) == (0, 0) is the top left of the screen.
        :raises MoreInputRequired: the codes end in the middle of a sequence and *more_available* is set.
        """
        if not keys:
            if more_available:
                raise MoreInputRequired()
            return None
        if keys[0] != ord("["):
            return None
        # read y value
        y = 0
        i = 1
        for k in keys[i:]:
            i += 1
            if k == ord(";"):
                if not y:
                    return None
                break
            if k < _ORD_0 or k > _ORD_9:
                return None
            if not y and k == _ORD_0:
                return None
            y = y * 10 + k - _ORD_0
        if not keys[i:]:
            if more_available:
                raise MoreInputRequired()
            return None
        # read x value
        x = 0
        for k in keys[i:]:
            i += 1
            if k == ord("R"):
                if not x:
                    return None
                return (("cursor position", x - 1, y - 1), keys[i:])
            if k < _ORD_0 or k > _ORD_9:
                return None
            if not x and k == _ORD_0:
                return None
            x = x * 10 + k - _ORD_0
        if not keys[i:] and more_available:
            raise MoreInputRequired()
        return None


# This is added to button value to signal mouse release by curses_display
# and raw_display when we know which button was released.  NON-STANDARD
MOUSE_RELEASE_FLAG = 2048

# This 2-bit mask is used to check if the mouse release from curses or gpm
# is a double or triple release. 00 means single click, 01 double,
# 10 triple. NON-STANDARD
MOUSE_MULTIPLE_CLICK_MASK = 1536

# This is added to button value at mouse release to differentiate between
# single, double and triple press. Double release adds this times one,
# triple release adds this times two.  NON-STANDARD
MOUSE_MULTIPLE_CLICK_FLAG = 512

# xterm adds this to the button value to signal a mouse drag event
MOUSE_DRAG_FLAG = 32

# Bits of the X10/SGR mouse report's button byte, per xterm's ctlseqs documentation of the
# "normal tracking mode" and "SGR mouse mode" reports.
_MOUSE_SHIFT_FLAG = 4
_MOUSE_META_FLAG = 8
_MOUSE_CTRL_FLAG = 16
_MOUSE_HIGH_BUTTON_FLAG = 64  # set to report buttons 4-7 (e.g. a wheel)
_MOUSE_EXTRA_BUTTON_FLAG = 128  # set to report buttons 8-11 (e.g. side buttons)
_MOUSE_BUTTON_MASK = 3  # low two bits: the button offset within its group
# button_bits == 3 with neither flag set means "released" (X10 report only); with either flag
# set it is the group's 4th button (7 or 11), which has no release encoding.

# The X10 report encodes the button byte and the two coordinate bytes by adding an offset to
# keep them in the printable ASCII range; coordinates are further offset by 1 since they are
# reported 1-based.
_MOUSE_BYTE_OFFSET = 32
_MOUSE_COORD_OFFSET = 33


#################################################
# Build the input trie from input_sequences list
input_trie = KeyqueueTrie(input_sequences)
#################################################

_keyconv = {
    8: "backspace",
    9: "tab",
    10: "enter",
    13: "enter",
    127: "backspace",
    # curses-only keycodes follow..  (XXX: are these used anymore?)
    258: "down",
    259: "up",
    260: "left",
    261: "right",
    262: "home",
    263: "backspace",
    265: "f1",
    266: "f2",
    267: "f3",
    268: "f4",
    269: "f5",
    270: "f6",
    271: "f7",
    272: "f8",
    273: "f9",
    274: "f10",
    275: "f11",
    276: "f12",
    277: "shift f1",
    278: "shift f2",
    279: "shift f3",
    280: "shift f4",
    281: "shift f5",
    282: "shift f6",
    283: "shift f7",
    284: "shift f8",
    285: "shift f9",
    286: "shift f10",
    287: "shift f11",
    288: "shift f12",
    330: "delete",
    331: "insert",
    338: "page down",
    339: "page up",
    343: "enter",  # on numpad
    350: "5",  # on numpad
    360: "end",
}

if IS_WINDOWS:
    _keyconv[351] = "shift tab"
    _keyconv[358] = "end"


def process_keyqueue(
    codes: list[int],
    more_available: bool,
) -> tuple[list[str | _MouseInput | _CursorPosition | _PrivateModeReport], list[int]]:
    """Decode `codes` into input events, consuming as much of the queue as is currently decodable.

    :param codes: list of key codes
    :param more_available: if True then raise MoreInputRequired when in the middle of a character sequence
        (escape/utf8/wide) and caller will attempt to send more key codes on the next call.
    :returns: a ``(list of input, list of remaining key codes)`` tuple.
    :raises MoreInputRequired: the codes end in the middle of a sequence and *more_available* is set.
    """
    code = codes[0]
    if 32 <= code <= 126:
        key = chr(code)
        return [key], codes[1:]
    if code in _keyconv:
        return [_keyconv[code]], codes[1:]
    if 0 < code < 27:
        return [f"ctrl {ord('a') + code - 1:c}"], codes[1:]
    if 27 < code < 32:
        return [f"ctrl {ord('A') + code - 1:c}"], codes[1:]

    em = str_util.get_byte_encoding()

    if em == "utf8" and 127 < code < 256:
        if code & 0xE0 == 0xC0:  # 2-byte form
            need_more = 1
        elif code & 0xF0 == 0xE0:  # 3-byte form
            need_more = 2
        elif code & 0xF8 == 0xF0:  # 4-byte form
            need_more = 3
        else:
            return [f"<{code:d}>"], codes[1:]

        for i in range(1, need_more + 1):
            if len(codes) <= i:
                if more_available:
                    raise MoreInputRequired()

                return [f"<{code:d}>"], codes[1:]

            k = codes[i]
            if k > 256 or k & 0xC0 != 0x80:
                return [f"<{code:d}>"], codes[1:]

        s = bytes(codes[: need_more + 1])

        try:
            return [s.decode("utf-8")], codes[need_more + 1 :]
        except UnicodeDecodeError:
            return [f"<{code:d}>"], codes[1:]

    if (
        em == "wide"
        and code < 256
        and str_util.within_double_byte(
            (start_code := code.to_bytes(1, "little")),
            0,
            0,
        )
    ):
        if not codes[1:] and more_available:
            raise MoreInputRequired()
        if codes[1:] and codes[1] < 256:
            end_code = codes[1].to_bytes(1, "little")

            if str_util.within_double_byte(start_code + end_code, 0, 1):
                return [chr(code) + chr(codes[1])], codes[2:]

    if 127 < code < 256:
        key = chr(code)
        return [key], codes[1:]
    if code != 27:
        return [f"<{code:d}>"], codes[1:]

    if (result := input_trie.get(codes[1:], more_available)) is not None:
        decoded, remaining_codes = result
        return [decoded], remaining_codes

    if codes[1:3] == [27, 27]:
        # With a third ESC following, the second one cannot start a sequence the first one prefixes as meta,
        # so decode the first one alone rather than recursing once per ESC in an arbitrarily long run.
        return ["esc"], codes[1:]

    if codes[1:]:
        # Meta keys -- ESC+Key form
        run, remaining_codes = process_keyqueue(codes[1:], more_available)
        # A mouse event or a terminal report (cursor position, DECRPM) cannot take a meta prefix.
        if not isinstance(run[0], str) or run[0] == "esc" or "meta " in run[0]:
            return ["esc", *run], remaining_codes
        return [f"meta {run[0]}", *run[1:]], remaining_codes

    return ["esc"], codes[1:]


####################
# Output sequences
####################

ESC = "\x1b"


class PrivateMode(str, enum.Enum):
    """DEC private modes (``CSI ? Pd h``/``l``).

    Not every member is queried or acted on, some members are for future development.
    `_raw_display_base.TermModes` carries a field for each regardless.
    """

    ALTERNATE_SCREEN_BUFFER = "1049"
    MOUSE_REPORTING = "1000"
    MOUSE_BUTTON_TRACKING = "1002"
    MOUSE_SGR_MODE = "1006"
    FOCUS_REPORTING = "1004"
    BRACKETED_PASTE = "2004"
    SYNCHRONIZED_OUTPUT = "2026"
    GRAPHEME_CLUSTERING = "2027"

    @functools.cached_property
    def query(self) -> str:
        """Return the DECRQM query (CSI ? Pd $ p) asking the terminal to report *mode*'s state."""
        return f"{ESC}[?{self}$p"

    @functools.cached_property
    def enable_seq(self) -> str:
        """Enable sequence."""
        return f"{ESC}[?{self}h"

    @functools.cached_property
    def disable_seq(self) -> str:
        """Disable sequence."""
        return f"{ESC}[?{self}l"

    # Plain value in f-strings/str(), matching enum.StrEnum (3.11+); drop in release 5 on py3.11+ migration.
    __str__ = str.__str__


CURSOR_HOME = f"{ESC}[H"
CURSOR_HOME_COL = "\r"

APP_KEYPAD_MODE = f"{ESC}="
NUM_KEYPAD_MODE = f"{ESC}>"

# Only for backward compatibility, temporary...
SWITCH_TO_ALTERNATE_BUFFER = PrivateMode.ALTERNATE_SCREEN_BUFFER.enable_seq
RESTORE_NORMAL_BUFFER = PrivateMode.ALTERNATE_SCREEN_BUFFER.disable_seq

ENABLE_BRACKETED_PASTE_MODE = PrivateMode.BRACKETED_PASTE.enable_seq
DISABLE_BRACKETED_PASTE_MODE = PrivateMode.BRACKETED_PASTE.disable_seq

ENABLE_FOCUS_REPORTING = PrivateMode.FOCUS_REPORTING.enable_seq
DISABLE_FOCUS_REPORTING = PrivateMode.FOCUS_REPORTING.disable_seq

# RESET_SCROLL_REGION = ESC+"[;r"
# RESET = ESC+"c"

REPORT_STATUS = f"{ESC}[5n"
REPORT_CURSOR_POSITION = f"{ESC}[6n"

# DECRQM (CSI ? Pd $ p) reply is DECRPM (CSI ? Pd ; Ps $ y), recognized by KeyqueueTrie.read_private_mode_report().
# Ps: 0 = not recognized, 1-4 = recognized.
DECRQM_RECOGNIZED_VALUES = frozenset({1, 2, 3, 4})

INSERT_ON = f"{ESC}[4h"
INSERT_OFF = f"{ESC}[4l"


def set_cursor_position(x: int, y: int) -> str:
    """
    Return the escape sequence that moves the cursor to column *x*, row *y*.

    :raises TypeError: *x* or *y* is not an integer.
    """
    if not isinstance(x, int):
        raise TypeError(x)
    if not isinstance(y, int):
        raise TypeError(y)

    return ESC + f"[{y + 1:d};{x + 1:d}H"


def move_cursor_right(x: int) -> str:
    """Return the escape sequence that moves the cursor right by *x* columns, or "" when *x* is not positive."""
    if x < 1:
        return ""
    return ESC + f"[{x:d}C"


def move_cursor_up(x: int) -> str:
    """Return the escape sequence that moves the cursor up by *x* rows, or "" when *x* is not positive."""
    if x < 1:
        return ""
    return ESC + f"[{x:d}A"


def move_cursor_down(x: int) -> str:
    """Return the escape sequence that moves the cursor down by *x* rows, or "" when *x* is not positive."""
    if x < 1:
        return ""
    return ESC + f"[{x:d}B"


HIDE_CURSOR = f"{ESC}[?25l"
SHOW_CURSOR = f"{ESC}[?25h"

_MOUSE_MODES = (PrivateMode.MOUSE_REPORTING, PrivateMode.MOUSE_BUTTON_TRACKING, PrivateMode.MOUSE_SGR_MODE)
MOUSE_TRACKING_ON = "".join(mode.enable_seq for mode in _MOUSE_MODES)
MOUSE_TRACKING_OFF = "".join(mode.disable_seq for mode in reversed(_MOUSE_MODES))

DESIGNATE_G1_SPECIAL = f"{ESC})0"

ERASE_IN_LINE_RIGHT = f"{ESC}[K"
