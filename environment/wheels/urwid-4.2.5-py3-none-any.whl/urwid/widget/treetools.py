# Generic TreeWidget/TreeWalker class
#    Copyright (c) 2010  Rob Lanphier
#    Copyright (C) 2004-2010  Ian Ward
#
#    This library is free software; you can redistribute it and/or
#    modify it under the terms of the GNU Lesser General Public
#    License as published by the Free Software Foundation; either
#    version 2.1 of the License, or (at your option) any later version.
#
#    This library is distributed in the hope that it will be useful,
#    but WITHOUT ANY WARRANTY; without even the implied warranty of
#    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the GNU
#    Lesser General Public License for more details.
#
#    You should have received a copy of the GNU Lesser General Public
#    License along with this library; if not, write to the Free Software
#    Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA  02111-1307  USA
#
# Urwid web site: https://urwid.org/


"""
Urwid tree view.

Features:
- custom selectable widgets for trees
- custom list walker for displaying widgets in a tree fashion
"""

from __future__ import annotations

import typing
import warnings

from .columns import Columns
from .constants import WHSettings
from .listbox import ListBox, ListWalker
from .padding import Padding
from .text import Text
from .widget import WidgetWrap
from .wimp import SelectableIcon

if typing.TYPE_CHECKING:
    from collections.abc import Hashable, Sequence

    from typing_extensions import Self

    from urwid.util import _TagMarkup

    from .listbox import VisibleInfo

__all__ = ("ParentNode", "TreeListBox", "TreeNode", "TreeWalker", "TreeWidget", "TreeWidgetError")

_T = typing.TypeVar("_T")
_Node = typing.TypeVar("_Node", bound="TreeNode[typing.Any] | ParentNode[typing.Any]")


class TreeWidgetError(RuntimeError):
    """Error raised for invalid tree widget usage."""


class TreeWidget(WidgetWrap[Padding[typing.Union[Text, Columns]]], typing.Generic[_Node]):
    """A widget representing something in a nested tree display."""

    indent_cols = 3
    unexpanded_icon = SelectableIcon("+", 0)
    expanded_icon = SelectableIcon("-", 0)

    def __init__(self, node: _Node) -> None:
        """Build the widget representing `node`, expanded by default."""
        self._node = node
        self._innerwidget: Text | None = None
        if not isinstance(node, ParentNode):
            if hasattr(node, "get_first_child"):
                warnings.warn(
                    f"get_first_child is defined, but node is not a ParentNode instance: {type(node)}",
                    DeprecationWarning,
                    stacklevel=2,
                )
                self.is_leaf = False
            else:
                self.is_leaf = True
        else:
            self.is_leaf = False

        self.expanded = True
        widget = self.get_indented_widget()
        super().__init__(widget)

    def selectable(self) -> bool:
        """Allow selection of non-leaf nodes so children may be (un)expanded."""
        return not self.is_leaf

    def get_indented_widget(self) -> Padding[Text | Columns]:
        """Return this node's widget wrapped with the expand/collapse icon and indentation."""
        widget: Text | Columns = self.get_inner_widget()
        if not self.is_leaf:
            widget = Columns(
                [(1, [self.unexpanded_icon, self.expanded_icon][self.expanded]), widget],
                dividechars=1,
            )
        indent_cols = self.get_indent_cols()
        return Padding(widget, width=(WHSettings.RELATIVE, 100), left=indent_cols)

    def update_expanded_icon(self) -> None:
        """Update display widget text for parent widgets."""
        # icon is first element in columns indented widget
        icon = [self.unexpanded_icon, self.expanded_icon][self.expanded]
        self._w.base_widget.contents[0] = (icon, (WHSettings.GIVEN, 1, False))  # type: ignore[attr-defined]

    def get_indent_cols(self) -> int:
        """Return the number of columns this widget is indented by, based on its node's depth."""
        return self.indent_cols * self.get_node().get_depth()

    def get_inner_widget(self) -> Text:
        """Return the cached inner widget, creating it with :meth:`load_inner_widget` if necessary."""
        if self._innerwidget is None:
            self._innerwidget = self.load_inner_widget()
        return self._innerwidget

    def load_inner_widget(self) -> Text:
        """Create the inner widget displaying this node's text."""
        return Text(self.get_display_text())

    def get_node(self) -> _Node:
        """Return the TreeNode this widget represents."""
        return self._node

    def get_display_text(self) -> _TagMarkup:
        """Return the text to display for this node, combining its key and value."""
        return f"{self.get_node().get_key()}: {self.get_node().get_value()!s}"

    def next_inorder(self) -> TreeWidget[TreeNode[typing.Any]] | None:
        """Return the next TreeWidget depth first from this one.

        :raises ValueError: the tree walker returned a node at an unexpected depth.
        """
        # first check if there's a child widget

        if (first_child := self.first_child()) is not None:
            return first_child

        # now we need to hunt for the next sibling
        this_node: TreeNode[typing.Any] = self.get_node()
        next_node = this_node.next_sibling()
        depth = this_node.get_depth()
        while next_node is None and depth > 0:
            # keep going up the tree until we find an ancestor next sibling
            this_node = this_node.get_parent()
            next_node = this_node.next_sibling()
            depth -= 1
            if depth != this_node.get_depth():
                raise ValueError(depth)
        if next_node is None:
            # we're at the end of the tree
            return None

        return next_node.get_widget()

    def prev_inorder(self) -> TreeWidget[TreeNode[typing.Any]] | None:
        """Return the previous TreeWidget depth first from this one."""
        this_node = self._node

        if (prev_node := this_node.prev_sibling()) is not None:
            # we need to find the last child of the previous widget if its
            # expanded
            prev_widget = prev_node.get_widget()
            if (last_child := prev_widget.last_child()) is not None:
                return last_child

            return prev_widget

        # need to hunt for the parent
        if this_node.get_depth() == 0:
            return None

        return this_node.get_parent().get_widget()

    def keypress(
        self,
        size: tuple[int] | tuple[()],
        key: str,
    ) -> str | None:
        """Handle expand & collapse requests (non-leaf nodes)."""
        if self.is_leaf:
            return key

        if key in {"+", "right"}:
            self.expanded = True
            self.update_expanded_icon()
            return None
        if key == "-":
            self.expanded = False
            self.update_expanded_icon()
            return None
        if self._w.selectable():
            return typing.cast("str | None", super().keypress(size, key))

        return key

    def mouse_event(
        self,
        size: tuple[int] | tuple[()],
        event: str,
        button: int,
        col: int,
        row: int,
        focus: bool,
    ) -> bool:
        """Toggle expand/collapse when the icon is left-clicked."""
        if self.is_leaf or event != "mouse press" or button != 1:
            return False

        if row == 0 and col == self.get_indent_cols():
            self.expanded = not self.expanded
            self.update_expanded_icon()
            return True

        return False

    def first_child(self) -> TreeWidget[TreeNode[typing.Any]] | None:
        """Return first child if expanded."""
        if self.is_leaf or not self.expanded:
            return None

        if typing.cast("ParentNode[typing.Any]", self._node).has_children():
            first_node = typing.cast("ParentNode[typing.Any]", self._node).get_first_child()
            return first_node.get_widget()

        return None

    def last_child(self) -> TreeWidget[TreeNode[typing.Any]] | None:
        """Return the last visible descendant if expanded.

        The descent is a loop rather than a recursion, so the depth of the tree is not limited by the
        interpreter's recursion limit.
        A descendant widget whose class overrides this method is asked for its own last descendant.

        :raises TreeWidgetError: the descent reaches a node it already passed, so the tree has a cycle.
        """
        # Keyed by id(), holding the node so the id cannot be reused by another node during the descent.
        visited: dict[int, TreeNode[typing.Any]] = {}
        last_descendant: TreeWidget[TreeNode[typing.Any]] | None = None
        widget: TreeWidget[typing.Any] = self
        while not widget.is_leaf and widget.expanded:
            node = typing.cast("ParentNode[typing.Any]", widget.get_node())
            if id(node) in visited:
                raise TreeWidgetError(f"Cycle in the tree: node {node.get_key()} is its own descendant")
            visited[id(node)] = node
            if not node.has_children():
                break
            widget = last_descendant = node.get_last_child().get_widget()
            if type(widget).last_child is not TreeWidget.last_child:
                if (overridden := widget.last_child()) is not None:
                    return overridden
                return widget

        return last_descendant


class TreeNode(typing.Generic[_T]):
    """Store tree contents and cache TreeWidget objects.

    A TreeNode consists of the following elements:
    *  key: accessor token for parent nodes
    *  value: subclass-specific data
    *  parent: a TreeNode which contains a pointer back to this object
    *  widget: The widget used to render the object
    """

    def __init__(
        self,
        value: _T,
        parent: ParentNode[typing.Any] | None = None,
        key: Hashable = None,
        depth: int | None = None,
    ) -> None:
        """Store `value` under `key`, with `parent` and `depth` as given, or computed from `parent` when omitted."""
        self._key = key
        self._parent = parent
        self._value = value
        self._depth = depth
        self._widget: TreeWidget[Self] | None = None

    def get_widget(self, reload: bool = False) -> TreeWidget[Self]:
        """Return the widget for this node."""
        if self._widget is None or reload:
            self._widget = self.load_widget()
        return self._widget

    def load_widget(self) -> TreeWidget[Self]:
        """Create the widget for this node."""
        return TreeWidget(self)

    def get_depth(self) -> int:
        """Return this node's depth in the tree, computing and caching it if necessary.

        The ancestors are walked in a loop rather than recursively, so the depth of the tree is not limited by the
        interpreter's recursion limit.
        Every ancestor whose depth was unknown caches its own depth as well.
        The walk stops at an ancestor whose class overrides this method, and uses the depth that ancestor returns.

        :raises TreeWidgetError: the parent links form a cycle.
        """
        if self._depth is not None:
            return self._depth

        # pylint: disable=protected-access  # the depth cache and parent link of other nodes of this class
        unresolved: list[TreeNode[typing.Any]] = []
        # ids of the nodes in ``unresolved``, which keeps them alive so no id is reused during the walk.
        visited: set[int] = set()
        depth = -1
        node: TreeNode[typing.Any] | None = self
        while node is not None:
            if node is not self and type(node).get_depth is not TreeNode.get_depth:
                depth = node.get_depth()
                break
            if node._depth is not None:
                depth = node._depth
                break
            if id(node) in visited:
                raise TreeWidgetError(f"Cycle in the tree: node {node.get_key()} is its own ancestor")
            visited.add(id(node))
            unresolved.append(node)
            node = node._parent

        for ancestor in reversed(unresolved):
            depth += 1
            ancestor._depth = depth
        return depth

    def get_index(self) -> int | None:
        """Return this node's position among its parent's children, or None for the root."""
        if self.get_depth() == 0:
            return None

        return self.get_parent().get_child_index(self.get_key())

    def get_key(self) -> Hashable:
        """Return this node's key."""
        return self._key

    def set_key(self, key: Hashable) -> None:
        """Set this node's key without updating the parent's reference to it."""
        self._key = key

    def change_key(self, key: Hashable) -> None:
        """Rename this node to ``key``, updating the parent's reference to it as well."""
        self.get_parent().change_child_key(self._key, key)

    def get_parent(self) -> ParentNode[typing.Any]:
        """Return this node's parent, loading it with :meth:`load_parent` if necessary."""
        if self._parent is None and self.get_depth() > 0:
            self._parent = self.load_parent()
        return typing.cast("ParentNode[typing.Any]", self._parent)

    def load_parent(self) -> ParentNode[typing.Any]:
        """Provide TreeNode with a parent for the current node.

        This function is only required if the tree was instantiated from a child node
        (virtual function)

        :raises TreeWidgetError: the subclass does not override this method.
        """
        raise TreeWidgetError("virtual function.  Implement in subclass")

    def get_value(self) -> _T:
        """Return this node's value."""
        return self._value

    def is_root(self) -> bool:
        """Return whether this node is the root of the tree."""
        return self.get_depth() == 0

    def next_sibling(self) -> TreeNode[typing.Any] | None:
        """Return the next sibling of this node, or None if there is none."""
        if self.get_depth() > 0:
            return self.get_parent().next_child(self.get_key())

        return None

    def prev_sibling(self) -> TreeNode[typing.Any] | None:
        """Return the previous sibling of this node, or None if there is none."""
        if self.get_depth() > 0:
            return self.get_parent().prev_child(self.get_key())

        return None

    def get_root(self) -> ParentNode[typing.Any]:
        """Return the root node of the tree this node belongs to."""
        root = self
        while root.get_parent() is not None:
            root = root.get_parent()
        return typing.cast("ParentNode[typing.Any]", root)


class ParentNode(TreeNode[_T]):
    """Maintain sort order for TreeNodes."""

    def __init__(
        self,
        value: typing.Any,
        parent: ParentNode[typing.Any] | None = None,
        key: Hashable = None,
        depth: int | None = None,
    ) -> None:
        """Store `value` under `key`, with no child keys loaded yet."""
        super().__init__(value, parent=parent, key=key, depth=depth)

        self._child_keys: Sequence[Hashable] | None = None
        self._children: dict[Hashable, TreeNode[typing.Any]] = {}
        # Position of each key in ``_indexed_keys``, the key list the map was built from.
        self._child_index: dict[Hashable, int] = {}
        self._indexed_keys: Sequence[Hashable] | None = None

    def get_child_keys(self, reload: bool = False) -> Sequence[Hashable]:
        """Return a possibly ordered list of child keys.

        A reload also drops the cached child nodes whose keys are no longer in the list.
        """
        if self._child_keys is None or reload:
            self._child_keys = self.load_child_keys()
            if reload:
                current = set(self._child_keys)
                self._children = {key: node for key, node in self._children.items() if key in current}
                self._child_index = {}
                self._indexed_keys = None
        return self._child_keys

    def load_child_keys(self) -> Sequence[Hashable]:
        """Provide ParentNode with an ordered list of child keys (virtual function).

        :raises TreeWidgetError: the subclass does not override this method.
        """
        raise TreeWidgetError("virtual function.  Implement in subclass")

    def get_child_widget(self, key: Hashable) -> TreeWidget[TreeNode[typing.Any]]:
        """Return the widget for a given key.  Create if necessary."""
        return self.get_child_node(key).get_widget()

    def get_child_node(self, key: Hashable, reload: bool = False) -> TreeNode[typing.Any]:
        """Return the child node for a given key. Create if necessary."""
        if key not in self._children or reload:
            self._children[key] = self.load_child_node(key)
        return self._children[key]

    def load_child_node(self, key: Hashable) -> TreeNode[typing.Any]:
        """Load the child node for a given key (virtual function).

        :raises TreeWidgetError: the subclass does not override this method.
        """
        raise TreeWidgetError("virtual function.  Implement in subclass")

    def set_child_node(self, key: Hashable, node: TreeNode[typing.Any]) -> None:
        """Set the child node for a given key.

        Useful for bottom-up, lazy population of a tree.
        """
        self._children[key] = node

    def change_child_key(self, oldkey: Hashable, newkey: Hashable) -> None:
        """
        Rename a child, moving it from *oldkey* to *newkey*.

        :raises TreeWidgetError: *newkey* is already used by another child.
        """
        if newkey in self._children:
            raise TreeWidgetError(f"{newkey} is already in use")
        self._children[newkey] = self._children.pop(oldkey)
        self._children[newkey].set_key(newkey)

    def get_child_index(self, key: Hashable) -> int:
        """
        Return the position of the child *key* among the child keys.

        :raises TreeWidgetError: *key* is not a child of this node.
        """
        child_keys = self.get_child_keys()
        index = self._child_index.get(key) if child_keys is self._indexed_keys else None
        if index is None or index >= len(child_keys) or child_keys[index] != key:
            # The map is missing or does not match the key list: it was reloaded, replaced, or changed in place.
            child_index: dict[Hashable, int] = {}
            for position, child_key in enumerate(child_keys):
                child_index.setdefault(child_key, position)
            self._child_index, self._indexed_keys = child_index, child_keys
            if (index := child_index.get(key)) is None:
                raise TreeWidgetError(
                    f"Can't find key {key} in ParentNode {self.get_key()}\nParentNode items: {child_keys!s}"
                )
        return index

    def next_child(self, key: Hashable) -> TreeNode[typing.Any] | None:
        """Return the next child node in index order from the given key."""
        if (index := self.get_child_index(key)) is not None and (index + 1) < len(child_keys := self.get_child_keys()):
            # get the next item at same level
            return self.get_child_node(child_keys[index + 1])

        # the given node may have just been deleted
        return None

    def prev_child(self, key: Hashable) -> TreeNode[typing.Any] | None:
        """Return the previous child node in index order from the given key."""
        if (index := self.get_child_index(key)) is not None and index >= 1:
            # get the previous item at the same level
            return self.get_child_node(self.get_child_keys()[index - 1])

        return None

    def get_first_child(self) -> TreeNode[typing.Any]:
        """Return the first TreeNode in the directory."""
        child_keys = self.get_child_keys()
        return self.get_child_node(child_keys[0])

    def get_last_child(self) -> TreeNode[typing.Any]:
        """Return the last TreeNode in the directory."""
        child_keys = self.get_child_keys()
        return self.get_child_node(child_keys[-1])

    def has_children(self) -> bool:
        """Return whether this node has any children."""
        return len(self.get_child_keys()) > 0


class TreeWalker(ListWalker[TreeNode[typing.Any], TreeWidget[TreeNode[typing.Any]]]):
    """ListWalker-compatible class for displaying TreeWidgets.

    positions are TreeNodes.
    """

    def __init__(self, start_from: TreeNode[typing.Any]) -> None:
        """start_from: TreeNode with the initial focus."""
        self.focus = start_from

    def get_focus(self) -> tuple[TreeWidget[TreeNode[typing.Any]], TreeNode[typing.Any]]:
        """Return the widget and node currently in focus."""
        widget = self.focus.get_widget()
        return widget, self.focus

    def set_focus(self, focus: TreeNode[typing.Any]) -> None:
        """Set the node in focus and notify listeners that the walker was modified."""
        self.focus = focus
        self._modified()

    # pylint: disable=arguments-renamed  # its bad, but we should not change API
    def get_next(
        self,
        start_from: TreeNode[typing.Any],
    ) -> tuple[TreeWidget[TreeNode[typing.Any]], TreeNode[typing.Any]] | tuple[None, None]:
        """Return the widget and node that follow ``start_from`` depth first, or ``(None, None)``."""
        if (target := start_from.get_widget().next_inorder()) is not None:
            return target, target.get_node()

        return None, None

    def get_prev(
        self,
        start_from: TreeNode[typing.Any],
    ) -> tuple[TreeWidget[TreeNode[typing.Any]], TreeNode[typing.Any]] | tuple[None, None]:
        """Return the widget and node that precede ``start_from`` depth first, or ``(None, None)``."""
        if (target := start_from.get_widget().prev_inorder()) is not None:
            return target, target.get_node()

        return None, None

    # pylint: enable=arguments-renamed


class TreeListBox(ListBox[TreeNode[typing.Any]]):
    """A ListBox with special handling for navigation and collapsing of TreeWidgets."""

    def keypress(
        self,
        size: tuple[int, int],  # type: ignore[override]
        key: str,
    ) -> str | None:
        """Handle a keypress, passing any unhandled key to :meth:`unhandled_input`."""
        if unhandled := super().keypress(size, key):
            return self.unhandled_input(size, unhandled)
        return None

    def unhandled_input(self, size: tuple[int, int], data: str) -> str | None:
        """Handle macro-navigation keys."""
        if data == "left":
            self.move_focus_to_parent(size)
            return None
        if data == "-":
            self.collapse_focus_parent(size)
            return None

        return data

    def collapse_focus_parent(self, size: tuple[int, int]) -> None:
        """Collapse parent directory."""
        _widget, pos = self.body.get_focus()
        self.move_focus_to_parent(size)

        _pwidget, ppos = self.body.get_focus()
        if pos != ppos:
            self.keypress(size, "-")

    def move_focus_to_parent(self, size: tuple[int, int]) -> None:
        """Move focus to parent of widget in focus."""
        _widget, pos = self.body.get_focus()

        parentpos = typing.cast("TreeNode[typing.Any]", pos).get_parent()

        if parentpos is None:
            return

        visible = typing.cast("VisibleInfo", self.calculate_visible(size))

        row_offset = visible.middle.offset

        for _widget, pos, rows in visible.top.fill:
            row_offset -= rows
            if pos == parentpos:
                self.change_focus(size, pos, row_offset)
                return

        self.change_focus(size, typing.cast("TreeNode[typing.Any]", pos).get_parent())

    def _keypress_max_left(self, size: tuple[int, int]) -> None:
        self.focus_home(size)

    def _keypress_max_right(self, size: tuple[int, int]) -> None:
        self.focus_end(size)

    def focus_home(self, size: tuple[int, int]) -> None:
        """Move focus to very top."""
        _widget, pos = self.body.get_focus()
        rootnode = typing.cast("TreeNode[typing.Any]", pos).get_root()
        self.change_focus(size, rootnode)

    def focus_end(self, size: tuple[int, int]) -> None:
        """Move focus to far bottom."""
        maxrow, _maxcol = size
        _widget, pos = self.body.get_focus()

        if lastwidget := typing.cast("TreeNode[typing.Any]", pos).get_root().get_widget().last_child():
            lastnode = lastwidget.get_node()

            self.change_focus(size, lastnode, maxrow - 1)
