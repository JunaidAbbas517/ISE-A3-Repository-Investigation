# Copyright (C) 2024 Urwid developers
#    This library is free software; you can redistribute it and/or
#    modify it under the terms of the GNU Lesser General Public
#    License as published by the Free Software Foundation; either
#    version 2.1 of the License, or (at your option) any later version.
#
#    This library is distributed in the hope that it will be useful,
#    but WITHOUT ANY WARRANTY; without even the implied warranty of
#    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the GNU
#    Lesser General Public License for more details.
#
#    You should have received a copy of the GNU Lesser General Public
#    License along with this library; if not, write to the Free Software
#    Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA  02111-1307  USA
#
# Urwid web site: https://urwid.org/
#
# Copyright (C) 2017-2024 rndusr (https://github.com/rndusr)
# Re-licensed from gpl-3.0 with author permission.
# Permission comment link: https://github.com/markqvist/NomadNet/pull/46#issuecomment-1892712616

"""Scrollable and ScrollBar: decorations that scroll a box widget."""

from __future__ import annotations

import contextlib
import dataclasses
import enum
import typing

from .constants import BOX_SYMBOLS, SHADE_SYMBOLS, Sizing
from .widget import AbstractBoxWidget, AbstractWidget
from .widget_decoration import WidgetDecoration, WidgetError

if typing.TYPE_CHECKING:
    from collections.abc import Iterator

    from typing_extensions import Literal

    from urwid import Canvas, CompositeCanvas

    from .container import WidgetContainerListContentsMixin
    from .widget import AbstractFixedWidget, AbstractFlowWidget


__all__ = (
    "ScrollBar",
    "Scrollable",
    "ScrollableError",
    "ScrollbarSymbols",
    "SupportsRelativeScroll",
    "SupportsScroll",
)


WrappedScrollableWidget = typing.TypeVar("WrappedScrollableWidget", bound="SupportsScroll")
WrappedScrollWidget = typing.TypeVar("WrappedScrollWidget", bound="AbstractFlowWidget | AbstractFixedWidget")


class ScrollableError(WidgetError):
    """Scrollable specific widget errors."""


# Scroll actions
SCROLL_LINE_UP = "line up"
SCROLL_LINE_DOWN = "line down"
SCROLL_PAGE_UP = "page up"
SCROLL_PAGE_DOWN = "page down"
SCROLL_TO_TOP = "to top"
SCROLL_TO_END = "to end"

# Scrollbar positions
SCROLLBAR_LEFT = "left"
SCROLLBAR_RIGHT = "right"


class ScrollbarSymbols(str, enum.Enum):
    """Common symbols suitable for scrollbar."""

    FULL_BLOCK = SHADE_SYMBOLS.FULL_BLOCK
    DARK_SHADE = SHADE_SYMBOLS.DARK_SHADE
    MEDIUM_SHADE = SHADE_SYMBOLS.MEDIUM_SHADE
    LITE_SHADE = SHADE_SYMBOLS.LITE_SHADE

    DRAWING_LIGHT = BOX_SYMBOLS.LIGHT.VERTICAL
    DRAWING_LIGHT_2_DASH = BOX_SYMBOLS.LIGHT.VERTICAL_2_DASH
    DRAWING_LIGHT_3_DASH = BOX_SYMBOLS.LIGHT.VERTICAL_3_DASH
    DRAWING_LIGHT_4_DASH = BOX_SYMBOLS.LIGHT.VERTICAL_4_DASH

    DRAWING_HEAVY = BOX_SYMBOLS.HEAVY.VERTICAL
    DRAWING_HEAVY_2_DASH = BOX_SYMBOLS.HEAVY.VERTICAL_2_DASH
    DRAWING_HEAVY_3_DASH = BOX_SYMBOLS.HEAVY.VERTICAL_3_DASH
    DRAWING_HEAVY_4_DASH = BOX_SYMBOLS.HEAVY.VERTICAL_4_DASH

    DRAWING_DOUBLE = BOX_SYMBOLS.DOUBLE.VERTICAL


@typing.runtime_checkable
class SupportsScroll(AbstractBoxWidget, typing.Protocol):
    """Scroll specific methods."""

    def get_scrollpos(self, size: tuple[int, int], focus: bool = False) -> int:
        """Return the index of the first visible row."""

    def rows_max(self, size: tuple[int, int] | None = None, focus: bool = False) -> int:
        """Return the total number of rows the widget can render."""


@typing.runtime_checkable
class SupportsRelativeScroll(AbstractBoxWidget, typing.Protocol):
    """Relative scroll-specific methods."""

    def require_relative_scroll(self, size: tuple[int, int], focus: bool = False) -> bool:
        """Return whether the widget should be scrolled using relative position rather than absolute rows."""

    def get_first_visible_pos(self, size: tuple[int, int], focus: bool = False) -> int:
        """Return the index of the first visible item."""

    def get_visible_amount(self, size: tuple[int, int], focus: bool = False) -> int:
        """Return the number of items currently visible."""


def orig_iter(w: AbstractWidget) -> Iterator[AbstractWidget]:
    """Yield `w` and each of its `original_widget` ancestors, stopping at the first cycle."""
    visited = {w}
    yield w
    while (w := getattr(w, "original_widget", w)) not in visited:
        visited.add(w)
        yield w


class Scrollable(WidgetDecoration[WrappedScrollWidget]):
    """Box widget decoration that makes a fixed or flow widget vertically scrollable."""

    def sizing(self) -> frozenset[Sizing]:
        """Return that this widget is always a box widget."""
        return frozenset((Sizing.BOX,))

    def selectable(self) -> bool:
        """Return ``True``: a scrollable widget always accepts the input focus."""
        return True

    def __init__(self, widget: WrappedScrollWidget, force_forward_keypress: bool = False) -> None:
        """Box widget that makes a fixed or flow widget vertically scrollable.

        .. note::
            Focusable widgets are handled, including switching focus, but possibly not intuitively,
            depending on the arrangement of widgets.

            When switching focus to a widget that is ouside of the visible part of the original widget,
            the canvas scrolls up/down to the focused widget.

            It would be better to scroll until the next focusable widget is in sight first.
            But for that to work we must somehow obtain a list of focusable rows in the original canvas.

        :raises ValueError: *widget* is neither a FIXED nor a FLOW widget.
        """
        if not widget.sizing() & frozenset((Sizing.FIXED, Sizing.FLOW)):
            raise ValueError(f"Not a fixed or flow widget: {widget!r}")

        self._trim_top = 0
        self._scroll_action: str | None = None
        self._forward_keypress: bool | None = None
        self._old_cursor_coords: tuple[int, int] | None = None
        self._rows_max_cached = 0
        self.force_forward_keypress = force_forward_keypress
        super().__init__(widget)

    def render(
        self,
        size: tuple[int, int],  # type: ignore[override]
        focus: bool = False,
    ) -> CompositeCanvas:
        """Render the wrapped widget, trimmed to the current scroll position."""
        from urwid import canvas

        maxcol, maxrow = size

        def automove_cursor() -> None:
            ch = 0
            last_hidden = False
            first_visible = False
            for pwi, (w, _o) in enumerate(
                typing.cast(
                    "WidgetContainerListContentsMixin[tuple[AbstractWidget, typing.Any]]",
                    ow,
                ).contents
            ):
                wcanv = w.render((maxcol,))

                if wh := wcanv.rows():
                    ch += wh

                if not last_hidden and ch >= self._trim_top:
                    last_hidden = True

                elif last_hidden:
                    if not first_visible:
                        first_visible = True

                    if not w.selectable():
                        continue

                    typing.cast(
                        "WidgetContainerListContentsMixin[tuple[AbstractWidget, typing.Any]]",
                        ow,
                    ).focus_position = pwi

                    st = None
                    nf = ow.focus
                    if hasattr(nf, "key_timeout"):
                        st = nf
                    elif (no := getattr(nf, "original_widget", None)) is not None:
                        if hasattr(no, "original_widget"):
                            st = no.original_widget
                        elif hasattr(no, "key_timeout"):
                            st = no

                    if st and hasattr(st, "key_timeout") and callable(getattr(st, "keypress", None)):
                        st.keypress(None, None)  # type: ignore[arg-type]  # Do not break legacy API

                    break

        # Render complete original widget
        ow = self._original_widget
        ow_size = self._get_original_widget_size(size)
        canv_full = ow.render(ow_size, focus)  # type: ignore[arg-type]

        # Make full canvas editable
        canv = canvas.CompositeCanvas(canv_full)
        canv_cols, canv_rows = canv.cols(), canv.rows()

        if canv_cols <= maxcol and (pad_width := maxcol - canv_cols) > 0:
            # Canvas is narrower than available horizontal space
            canv.pad_trim_left_right(0, pad_width)

        if canv_rows <= maxrow and (fill_height := maxrow - canv_rows) > 0:
            # Canvas is lower than available vertical space
            canv.pad_trim_top_bottom(0, fill_height)

        if canv_cols <= maxcol and canv_rows <= maxrow:
            # Canvas is small enough to fit without trimming
            return canv

        self._adjust_trim_top(canv, size)

        # Trim canvas if necessary
        trim_top = self._trim_top
        trim_end = canv_rows - maxrow - trim_top
        trim_right = canv_cols - maxcol
        if trim_top > 0:
            canv.trim(trim_top)
        if trim_end > 0:
            canv.trim_end(trim_end)
        if trim_right > 0:
            canv.pad_trim_left_right(0, -trim_right)

        # Disable cursor display if cursor is outside of visible canvas parts
        if canv.cursor is not None:
            # Pylint check acts here a bit weird.
            _curscol, cursrow = canv.cursor  # pylint: disable=unpacking-non-sequence,useless-suppression
            if cursrow >= maxrow or cursrow < 0:
                canv.cursor = None

        # Figure out whether we should forward keypresses to original widget
        if canv.cursor is not None:
            # Trimmed canvas contains the cursor, e.g. in an Edit widget
            self._forward_keypress = True
        elif canv_full.cursor is not None:
            # Full canvas contains the cursor, but scrolled out of view
            self._forward_keypress = False

            # Reset cursor position on page/up down scrolling
            if getattr(ow, "automove_cursor_on_scroll", False):
                with contextlib.suppress(Exception):
                    automove_cursor()

        else:
            # Original widget does not have a cursor, but may be selectable

            # FIXME: Using ow.selectable() is bad because the original
            # widget may be selectable because it's a container widget with
            # a key-grabbing widget that is scrolled out of view.
            # ow.selectable() returns True anyway because it doesn't know
            # how we trimmed our canvas.
            #
            # To fix this, we need to resolve ow.focus and somehow
            # ask canv whether it contains bits of the focused widget.  I
            # can't see a way to do that.
            self._forward_keypress = ow.selectable()

        return canv

    def keypress(
        self,
        size: tuple[int, int],  # type: ignore[override]
        key: str,
    ) -> str | None:
        """Handle scrolling keys, forwarding everything else to the wrapped widget when appropriate."""
        from urwid.command_map import Command

        # Maybe offer key to original widget
        if self._forward_keypress or self.force_forward_keypress:
            ow = self._original_widget
            ow_size = self._get_original_widget_size(size)

            # Remember the previous cursor position if possible
            if hasattr(ow, "get_cursor_coords"):
                self._old_cursor_coords = ow.get_cursor_coords(ow_size)

            if (handled := ow.keypress(ow_size, key)) is not None:  # type: ignore[arg-type]
                key = handled
            else:
                return None

        # Handle up/down, page up/down, etc.
        command_map = self._command_map
        if command_map[key] == Command.UP:
            self._scroll_action = SCROLL_LINE_UP
        elif command_map[key] == Command.DOWN:
            self._scroll_action = SCROLL_LINE_DOWN

        elif command_map[key] == Command.PAGE_UP:
            self._scroll_action = SCROLL_PAGE_UP
        elif command_map[key] == Command.PAGE_DOWN:
            self._scroll_action = SCROLL_PAGE_DOWN

        elif command_map[key] == Command.MAX_LEFT:  # 'home'
            self._scroll_action = SCROLL_TO_TOP
        elif command_map[key] == Command.MAX_RIGHT:  # 'end'
            self._scroll_action = SCROLL_TO_END

        else:
            return key

        self._invalidate()
        return None

    def mouse_event(
        self,
        size: tuple[int, int],  # type: ignore[override]
        event: str,
        button: int,
        col: int,
        row: int,
        focus: bool,
    ) -> bool | None:
        """Forward a mouse event to the wrapped widget, adjusting the row for the current scroll position."""
        ow = self._original_widget
        if hasattr(ow, "mouse_event"):
            ow_size = self._get_original_widget_size(size)
            row += self._trim_top
            return ow.mouse_event(
                ow_size,  # type: ignore[arg-type]
                event,
                button,
                col,
                row,
                focus,
            )

        return False

    def _adjust_trim_top(self, canv: Canvas, size: tuple[int, int]) -> None:
        """Adjust self._trim_top according to self._scroll_action."""
        action = self._scroll_action
        self._scroll_action = None

        _maxcol, maxrow = size
        trim_top = self._trim_top
        canv_rows = canv.rows()

        if trim_top < 0:
            # Negative trim_top values use bottom of canvas as reference
            trim_top = canv_rows - maxrow + trim_top + 1

        if canv_rows <= maxrow:
            self._trim_top = 0  # Reset scroll position
            return

        if action == SCROLL_LINE_UP:
            self._trim_top = max(0, min(canv_rows - maxrow, trim_top - 1))
        elif action == SCROLL_LINE_DOWN:
            self._trim_top = max(0, min(canv_rows - maxrow, trim_top + 1))

        elif action == SCROLL_PAGE_UP:
            self._trim_top = max(0, min(canv_rows - maxrow, trim_top - maxrow + 1))
        elif action == SCROLL_PAGE_DOWN:
            self._trim_top = max(0, min(canv_rows - maxrow, trim_top + maxrow - 1))

        elif action == SCROLL_TO_TOP:
            self._trim_top = 0
        elif action == SCROLL_TO_END:
            self._trim_top = canv_rows - maxrow

        else:
            self._trim_top = max(0, min(canv_rows - maxrow, trim_top))

        # If the cursor was moved by the most recent keypress, adjust trim_top
        # so that the new cursor position is within the displayed canvas part.
        # But don't do this if the cursor is at the top/bottom edge so we can still scroll out
        if self._old_cursor_coords is not None and self._old_cursor_coords != canv.cursor and canv.cursor is not None:
            self._old_cursor_coords = None
            _curscol, cursrow = canv.cursor
            if cursrow < self._trim_top:
                self._trim_top = cursrow
            elif cursrow >= self._trim_top + maxrow:
                self._trim_top = max(0, cursrow - maxrow + 1)

    def _get_original_widget_size(
        self,
        size: tuple[int, int],
    ) -> tuple[int] | tuple[()]:
        """
        Return the size to render the wrapped widget with.

        :raises ScrollableError: the wrapped widget supports neither FLOW nor FIXED sizing.
        """
        ow = self._original_widget
        sizing = ow.sizing()
        if Sizing.FLOW in sizing:
            return (size[0],)
        if Sizing.FIXED in sizing:
            return ()
        raise ScrollableError(f"{ow!r} sizing is not supported")

    def get_scrollpos(self, size: tuple[int, int] | None = None, focus: bool = False) -> int:
        """Return the current scrolling position.

        Lower limit is 0, upper limit is the maximum number of rows with the given maxcol minus maxrow.

        ..note::
            The returned value may be too low or too high if the position has
            changed but the widget wasn't rendered yet.
        """
        return self._trim_top

    def set_scrollpos(self, position: typing.SupportsInt) -> None:
        """Set scrolling position.

        If `position` is positive it is interpreted as lines from the top.
        If `position` is negative it is interpreted as lines from the bottom.

        Values that are too high or too low values are automatically adjusted during rendering.
        """
        self._trim_top = int(position)
        self._invalidate()

    def rows_max(self, size: tuple[int, int] | None = None, focus: bool = False) -> int:
        """Return the number of rows for `size`.

        If `size` is not given, the currently rendered number of rows is returned.

        :raises ScrollableError: the wrapped widget is neither a FLOW nor a FIXED widget.
        """
        if size is not None:
            ow = self._original_widget
            ow_size = self._get_original_widget_size(size)
            sizing = ow.sizing()
            if Sizing.FIXED in sizing:
                self._rows_max_cached = ow.pack(ow_size, focus)[1]  # type: ignore[arg-type]
            elif Sizing.FLOW in sizing:
                self._rows_max_cached = typing.cast("AbstractFlowWidget", ow).rows(
                    typing.cast("tuple[int]", ow_size),
                    focus,
                )
            else:
                raise ScrollableError(f"Not a flow/fixed widget: {self._original_widget!r}")
        return self._rows_max_cached


@dataclasses.dataclass(frozen=True)
class _ScrollbarLayout:
    """Geometry of a scrollbar rendered next to its wrapped widget.

    Produced by :meth:`ScrollBar._scrollbar_layout` and shared between rendering and mouse handling
    so the scrollbar hit-box and the thumb placement always stay in sync.
    """

    ow_size: tuple[int, int]
    sb_width: int
    pos: int
    posmax: int
    thumb_height: int
    top_height: int
    bottom_height: int


class ScrollBar(WidgetDecoration[WrappedScrollableWidget]):
    """Box widget decoration that adds a scrollbar alongside a scrollable wrapped widget."""

    Symbols = ScrollbarSymbols

    def sizing(self) -> frozenset[Sizing]:
        """Return that this widget is always a box widget."""
        return frozenset((Sizing.BOX,))

    def selectable(self) -> bool:
        """Return ``True``: a scrollbar-wrapped widget always accepts the input focus."""
        return True

    def __init__(
        self,
        widget: WrappedScrollableWidget,
        thumb_char: str = ScrollbarSymbols.FULL_BLOCK,
        trough_char: str = " ",
        side: Literal["left", "right"] = SCROLLBAR_RIGHT,  # type: ignore[assignment]  # constant
        width: int = 1,
    ) -> None:
        """Box widget that adds a scrollbar to `widget`.

        `widget` must be a box widget with the following methods:
          - `get_scrollpos` takes the arguments `size` and `focus` and returns the index of the first visible row.
          - `set_scrollpos` (optional; needed for mouse click support) takes the index of the first visible row.
          - `rows_max` takes `size` and `focus` and returns the total number of rows `widget` can render.

        `thumb_char` is the character used for the scrollbar handle.
        `trough_char` is used for the space above and below the handle.
        `side` must be 'left' or 'right'.
        `width` specifies the number of columns the scrollbar uses.

        :raises ValueError: *widget* is not a BOX widget.
        :raises TypeError: *widget* does not wrap anything that supports the scrolling protocol.
        """
        if Sizing.BOX not in widget.sizing():
            raise ValueError(f"Not a box widget: {widget!r}")

        if not any(isinstance(w, SupportsScroll) for w in orig_iter(widget)):
            raise TypeError(f"Not a scrollable widget: {widget!r}")

        super().__init__(widget)
        self._thumb_char = thumb_char
        self._trough_char = trough_char
        self.scrollbar_side = side
        self.scrollbar_width = max(1, width)
        self._original_widget_size = (0, 0)

    def _render_original(
        self,
        size: tuple[int, int],
        focus: bool = False,
    ) -> Canvas:
        self._original_widget_size = size
        return self._original_widget.render(size, focus)

    def _scrollbar_layout(
        self,
        size: tuple[int, int],
        focus: bool = False,
    ) -> _ScrollbarLayout | None:
        """Compute the scrollbar geometry for ``size``.

        :returns: ``None`` is returned as a "not shown" flag when the wrapped widget fits without scrolling
            and therefore no scrollbar is drawn.
            Otherwise, the thumb and trough placement is returned,
            so :meth:`render` and :meth:`mouse_event` can share the same geometry without duplicating the maths.
        :raises TypeError: the wrapped widget does not support the scrolling protocol.
        """
        maxcol, maxrow = size

        ow_size = (max(0, maxcol - self._scrollbar_width), maxrow)
        sb_width = maxcol - ow_size[0]

        ow_base = self.scrolling_base_widget

        # Use hasattr instead of protocol: hasattr will return False in case of getattr raise AttributeError
        # Use __length_hint__ first since it's less resource intensive
        require_absolute = True

        if (
            isinstance(ow_base, SupportsRelativeScroll)
            and callable(len_getter := getattr(ow_base, "__len__", getattr(ow_base, "__length_hint__", None)))
            and ow_base.require_relative_scroll(size, focus)
        ):
            # `operator.length_hint` is Protocol (Spec) over class base and can end false-negative on the instance
            # use length_hint-like approach with safe `AttributeError` handling
            ow_len = len_getter()
            visible_amount = ow_base.get_visible_amount(ow_size, focus)
            pos = ow_base.get_first_visible_pos(ow_size, focus)

            # in the case of estimated length, it can be smaller than real widget length
            ow_len = max(ow_len, visible_amount, pos)
            posmax = ow_len - visible_amount
            thumb_weight = min(1.0, visible_amount / max(1, ow_len))

            # Corner case possible: formally all contents indexes should be visible, but this does not mean all rows
            if ow_len != visible_amount:
                require_absolute = False

        if require_absolute:
            if isinstance(ow_base, SupportsScroll):
                if ow_base.rows_max(size, focus) > maxrow:
                    # re-calculate using wrapped size
                    ow_rows_max = ow_base.rows_max(ow_size, focus)
                    pos = ow_base.get_scrollpos(ow_size, focus)
                    posmax = ow_rows_max - maxrow
                    thumb_weight = min(1.0, maxrow / max(1, ow_rows_max))

                else:
                    # Canvas fits without scrolling - no scrollbar needed
                    return None
            else:
                raise TypeError(f"Not a scrollable widget: {ow_base!r}")

        # Thumb shrinks/grows according to the ratio of <number of visible lines> / <number of total lines>
        thumb_height = max(1, round(thumb_weight * maxrow))  # pylint: disable=possibly-used-before-assignment

        # Thumb may only touch top/bottom if the first/last row is visible
        top_weight = float(pos) / max(1, posmax)  # pylint: disable=possibly-used-before-assignment
        top_height = int((maxrow - thumb_height) * top_weight)
        if top_height == 0 and top_weight > 0:
            top_height = min(1, maxrow - thumb_height)

        # Bottom part is remaining space
        bottom_height = maxrow - thumb_height - top_height

        return _ScrollbarLayout(
            ow_size=ow_size,
            sb_width=sb_width,
            pos=pos,
            posmax=posmax,
            thumb_height=thumb_height,
            top_height=top_height,
            bottom_height=bottom_height,
        )

    def render(
        self,
        size: tuple[int, int],  # type: ignore[override]
        focus: bool = False,
    ) -> Canvas:
        """Render the wrapped widget together with the scrollbar, when scrolling is needed."""
        from urwid import canvas

        maxcol, maxrow = size

        # Render the wrapped widget first
        # so any pending scroll action is applied before the scroll position is queried for the scrollbar geometry.
        ow_size = (max(0, maxcol - self._scrollbar_width), maxrow)
        ow_canv = self._render_original(ow_size, focus)

        layout = self._scrollbar_layout(size, focus)
        if layout is None:
            # Canvas fits without scrolling - no scrollbar needed
            return self._render_original(size, focus)

        # Create scrollbar canvas
        # Creating SolidCanvases of correct height may result in
        # "cviews do not fill gaps in shard_tail!" or "cviews overflow gaps in shard_tail!" exceptions.
        # Stacking the same SolidCanvas is a workaround.
        # https://github.com/urwid/urwid/issues/226#issuecomment-437176837
        top = canvas.SolidCanvas(self._trough_char, layout.sb_width, 1)
        thumb = canvas.SolidCanvas(self._thumb_char, layout.sb_width, 1)
        bottom = canvas.SolidCanvas(self._trough_char, layout.sb_width, 1)
        sb_canv = canvas.CanvasCombine(
            (
                *((top, None, False) for _ in range(layout.top_height)),
                *((thumb, None, False) for _ in range(layout.thumb_height)),
                *((bottom, None, False) for _ in range(layout.bottom_height)),
            ),
        )

        combinelist = [
            (ow_canv, None, True, layout.ow_size[0]),
            (sb_canv, None, False, layout.sb_width),
        ]

        if self._scrollbar_side != SCROLLBAR_LEFT:
            return canvas.CanvasJoin(combinelist)

        return canvas.CanvasJoin(reversed(combinelist))

    @property
    def scrollbar_width(self) -> int:
        """Columns the scrollbar uses."""
        return max(1, self._scrollbar_width)

    @scrollbar_width.setter
    def scrollbar_width(self, width: typing.SupportsInt) -> None:
        self._scrollbar_width = max(1, int(width))
        self._invalidate()

    @property
    def scrollbar_side(self) -> Literal["left", "right"]:
        """Where to display the scrollbar; must be 'left' or 'right'."""
        return self._scrollbar_side

    @scrollbar_side.setter
    def scrollbar_side(self, side: Literal["left", "right"]) -> None:
        """
        Set the side of the widget the scrollbar is drawn on.

        :raises ValueError: *side* is neither ``'left'`` nor ``'right'``.
        """
        if side not in {SCROLLBAR_LEFT, SCROLLBAR_RIGHT}:
            raise ValueError(f'scrollbar_side must be "left" or "right", not {side!r}')
        self._scrollbar_side = side
        self._invalidate()

    @property
    def scrolling_base_widget(self) -> SupportsScroll | SupportsRelativeScroll:
        """Nearest `original_widget` that is compatible with the scrolling API.

        :raises ScrollableError: no wrapped widget supports the scrolling protocol.
        """
        w = self

        for w in orig_iter(self):  # type: ignore[assignment]
            if isinstance(w, SupportsScroll):
                return w

        raise ScrollableError(f"Not compatible to be wrapped by ScrollBar: {w!r}")

    def keypress(
        self,
        size: tuple[int, int],  # type: ignore[override]
        key: str,
    ) -> str | None:
        """Forward a keypress to the wrapped widget."""
        return self._original_widget.keypress(self._original_widget_size, key)

    def mouse_event(
        self,
        size: tuple[int, int],  # type: ignore[override]
        event: str,
        button: int,
        col: int,
        row: int,
        focus: bool,
    ) -> bool | None:
        """Handle a mouse event, dispatching it to the scrollbar thumb/trough or to the wrapped widget."""
        ow = self._original_widget
        ow_size = self._original_widget_size
        supports_scroll = hasattr(ow, "set_scrollpos")
        on_scrollbar = False
        ow_col = col

        if supports_scroll:
            # The geometry is needed before the event is passed on: the wrapped widget cannot tell
            # that a column belongs to the scrollbar, and would answer a click that is not its own.
            layout = self._scrollbar_layout(size, focus)
            if layout is not None:
                if self._scrollbar_side == SCROLLBAR_LEFT:
                    on_scrollbar = col < layout.sb_width
                    # The wrapped widget is drawn after the scrollbar, so its own column 0 sits at
                    # screen column sb_width and the offset has to be taken back out.
                    ow_col = col - layout.sb_width
                else:
                    on_scrollbar = col >= layout.ow_size[0]

                if on_scrollbar and button == 1:
                    # Move the thumb top to the clicked row, inverting the placement done during render.
                    thumb_travel = size[1] - layout.thumb_height
                    if thumb_travel > 0:
                        newpos = round(row * layout.posmax / thumb_travel)
                    else:
                        newpos = 0
                    ow.set_scrollpos(max(0, min(layout.posmax, newpos)))  # type: ignore[attr-defined]  # gated
                    return True

        handled: bool | None = False
        if not on_scrollbar and hasattr(ow, "mouse_event"):
            handled = ow.mouse_event(ow_size, event, button, ow_col, row, focus)

        if not handled and supports_scroll:
            if button == 4:  # scroll wheel up
                pos = ow.get_scrollpos(ow_size)
                newpos = max(pos - 1, 0)
                ow.set_scrollpos(newpos)  # type: ignore[attr-defined]  # gated
                return True
            if button == 5:  # scroll wheel down
                pos = ow.get_scrollpos(ow_size)
                ow.set_scrollpos(pos + 1)  # type: ignore[attr-defined]  # gated
                return True

        return handled
